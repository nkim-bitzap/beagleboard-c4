/*
 * Copyright (C) 2010-2011 University of Texas at Austin
 *
 * Author: Dan Zhang <dan.zhang@mail.utexas.edu>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */



/* The default DSP behavior is as follows:

   while(1) {
      run idle function
      
      if(message available)
         run function specified by the message's command

*/


// Define your non-temporary variables here:
struct dsp_global_t{
  uint32_t counter;
  int j;
};

// Initialize them here
inline void dsp_init_vars(struct dsp_global_t* global) {
  global->counter = 0;
  global->j = 0;
}


/* The number of DSP functions that you wish to run. In this example,
   the only function to run is the matrix multiply function. */
#define NUM_DSP_FUNC 3

/* Message send and receive sizes. Do not exceed the maximum.
   The send and receive DMA buffers are sized to be the maximum. If
   you do not need the space, you may reduce the size as you see fit.
 */
#define MAX_SEND_SIZE 512*1024     // 512KB
#define MAX_RECEIVE_SIZE 512*1024  // 512KB


/* These are the functions that the DSP can run. A function pointer
   array accesses them based on the message command # sent to the DSP.
*/
void matrix_mul(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused);
void matrix_mul_fast(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused);
void vector_add(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused);


// Map msg.cmd number to function to run.
// WARNING: 0 and 0x80000000 are reserved, don't use it!
#define RESERVED1 0
#define MATRIX_MUL 1
#define VECTOR_ADD 2
#define MATRIX_MUL_FAST 3
#define RESERVED2 0x80000000

// The indices into the array should match the above.
inline void init_dsp_func(void (**pt2Func)(struct dsp_global_t*, void*, void*, uint32_t, uint32_t)) {
  pt2Func[1] = matrix_mul;
  pt2Func[2] = vector_add;
  pt2Func[3] = matrix_mul_fast;
}



// Do you actually wish to run the idle function? If so, uncomment. 
// Else, comment.
#define DSP_IDLE_FUNC_EN

// DSP Idle Function (see explanation above)
inline void dsp_idle_func(struct dsp_global_t* global) {
  global->counter++;
}


// Function specified by message command
void matrix_mul(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused) {
  uint32_t i, j, k;
  uint32_t sum;

  uint32_t* a;
  uint32_t* b;
  uint32_t* c;
  // Generate matrices A and B
  a = (uint32_t*)in;
  b = &(a[size*size]); // matrix has dimensions size*size
  c = (uint32_t*)out;
  
  for(i = 0; i < size; i=i+1) {
    for(j = 0; j < size; j=j+1) {
      sum = 0; 
      for(k = 0; k < size; k=k+1) {
	sum += a[j*size+k]*b[k*size+i];
      }
      c[j*size + i] = sum;
    }
  }
  
  c[0] = global->counter;
}

#define BLK_SIZE 32


void matrix_mul_fast(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused) {
  uint32_t ii, jj, kk;
  uint32_t i, j, k;
  uint32_t sum0, sum1, sum2, sum3, sum4, sum5, sum6, sum7;

  uint32_t* a;
  uint32_t* b;
  //  uint32_t* b_new;
  uint32_t* c;

  // Generate matrices A and B
  a = (uint32_t*)in;
  b = &(a[size*size]); // matrix has dimensions size*size
  c = (uint32_t*)out;
  
  // Change B from row-major to column-major
  //b_new = (uint32_t*)malloc(size*size*sizeof(uint32_t));
  /*
  for(i = 0; i < size; i=i+1) {
    for(j = 0; j < size; j=j+8) {
      b_new[(j+0)*size+i] = b[i*size+j+0];
      b_new[(j+1)*size+i] = b[i*size+j+1];
      b_new[(j+2)*size+i] = b[i*size+j+2];
      b_new[(j+3)*size+i] = b[i*size+j+3];
      b_new[(j+4)*size+i] = b[i*size+j+4];
      b_new[(j+5)*size+i] = b[i*size+j+5];
      b_new[(j+6)*size+i] = b[i*size+j+6];
      b_new[(j+7)*size+i] = b[i*size+j+7];
    }
  }
  */

  for(i = 0; i < size; i=i+BLK_SIZE) {
    for(j = 0; j < size; j=j+BLK_SIZE) {
      for(k = 0; k < size; k=k+BLK_SIZE) {
	for(ii = i; ii < i+BLK_SIZE;ii=ii+1) {
	  for(jj = j; jj < j+BLK_SIZE;jj=jj+1) {
	    sum0 = 0; 
	    sum1 = 0;
	    sum2 = 0;
	    sum3 = 0;
	    sum4 = 0;
	    sum5 = 0;
	    sum6 = 0;
	    sum7 = 0;
	    for(kk = k; kk < k+BLK_SIZE;kk=kk+8) {
	      sum0 += a[jj*size+kk+0]*b[(kk+0)*size+ii];
	      sum1 += a[jj*size+kk+1]*b[(kk+1)*size+ii];
	      sum2 += a[jj*size+kk+2]*b[(kk+2)*size+ii];
	      sum3 += a[jj*size+kk+3]*b[(kk+3)*size+ii];
	      sum4 += a[jj*size+kk+4]*b[(kk+4)*size+ii];
	      sum5 += a[jj*size+kk+5]*b[(kk+5)*size+ii];
	      sum6 += a[jj*size+kk+6]*b[(kk+6)*size+ii];
	      sum7 += a[jj*size+kk+7]*b[(kk+7)*size+ii];
	    }
	    c[jj*size + ii] = sum0+sum1+sum2+sum3+sum4+sum5+sum6+sum7;
	  }
	}
      }
    }
  }
  

  //free(b_new);
  c[0] = global->counter;
}

void vector_add(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused) {
  uint32_t i;
  int* a;
  int* b;
  int* c;
  // Generate matrices A and B
  a = (int*)in;
  b = &(a[size*size]); // matrix has dimensions size*size
  c = (int*)out;

  for(i = 0; i < size*size; i++)
    c[i] = a[i]+b[i];

  c[0] = global->counter;
  c[1] = 1336;

  return;
}
