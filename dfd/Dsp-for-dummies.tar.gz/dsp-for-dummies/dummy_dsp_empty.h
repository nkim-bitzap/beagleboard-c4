/*
 * Copyright (C) 2010-2011 University of Texas at Austin
 *
 * Author: Dan Zhang <dan.zhang@mail.utexas.edu>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */



/* The default DSP behavior is as follows:

   while(1) {
      run idle function
      
      if(message available)
         run function specified by the message's command

*/


// Define your non-temporary variables here:
struct dsp_global_t{
};

// Initialize them here
inline void dsp_init_vars(struct dsp_global_t* global) {
}


/* The number of DSP functions that you wish to run. In this example,
   the only function to run is the matrix multiply function. */
#define NUM_DSP_FUNC 0

/* Message send and receive sizes. Do not exceed the maximum.
   The send and receive DMA buffers are sized to be the maximum. If
   you do not need the space, you may reduce the size as you see fit.
 */
#define MAX_SEND_SIZE 512*1024     // 512KB
#define MAX_RECEIVE_SIZE 512*1024  // 512KB


/* These are the functions that the DSP can run. A function pointer
   array accesses them based on the message command # sent to the DSP.
*/
void do_nothing(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused);


// Map msg.cmd number to function to run.
// WARNING: 0 and 0x80000000 are reserved, don't use it!
#define RESERVED1 0
#define DO_NOTHING 1
#define RESERVED2 0x80000000

// The indices into the array should match the above.
inline void init_dsp_func(void (**pt2Func)(struct dsp_global_t*, void*, void*, uint32_t, uint32_t)) {
  pt2Func[1] = do_nothing;
}



// Do you actually wish to run the idle function? If so, uncomment. 
// Else, comment.
//#define DSP_IDLE_FUNC_EN

// DSP Idle Function (see explanation above)
inline void dsp_idle_func(struct dsp_global_t* global) {
}


// Function specified by message command
void do_nothing(struct dsp_global_t* global, void* in, void* out, uint32_t size, uint32_t unused) {
  
  return;
}
