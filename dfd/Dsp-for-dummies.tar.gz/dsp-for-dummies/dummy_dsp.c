/*
 * Copyright (C) 2008-2009 Nokia Corporation.
 *
 * Author: Felipe Contreras <felipe.contreras@nokia.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <stddef.h>
#include "node.h"
#include "dummy_dsp.h"

unsigned int
dummy_create(void)
{
  return 0x8000;
}

unsigned int
dummy_delete(void)
{
  return 0x8000;
}


unsigned int
dummy_execute(void *env)
{
  dsp_msg_t msg;
  void *input;
  void *output;
  unsigned char done = 0;
  unsigned short status;
  struct dsp_global_t global;

  // Function pointer array
  void (*dsp_func[NUM_DSP_FUNC+1]) (struct dsp_global_t*, void*, void*, uint32_t, uint32_t);

  init_dsp_func(dsp_func);

  // Initialize global variables in dummy_dsp.h
  dsp_init_vars(&global);


  while (!done) {


    status = NODE_getMsg(env, &msg, 0); //(unsigned) -1);

    if(status != 1) {
#ifdef DSP_IDLE_FUNC_EN
    // Call idle function (runs when no message)
    dsp_idle_func(&global);
#endif
      continue;
    }

    switch (msg.cmd) {
    case 0:
      input = (void *) (msg.arg_1);
      output = (void *) (msg.arg_2);
      break;
    case 0x80000000:
      done = 1;
      break;
    default:
      {
	uint32_t arg1;
	uint32_t arg2;
				
	// Size is in BYTES
	arg1 = msg.arg_1;
	arg2 = msg.arg_2;

	/*
	  Cache coherence: invalidate the old
	  input buffer in the cache and fetch
	  the new input buffer from mem
	*/
	BCACHE_inv(input, MAX_SEND_SIZE, 1);

	// Main program body

	dsp_func[msg.cmd](&global, input, output, arg1, arg2);

	/*
	  Cache coherence: write the output
	  buffer from cache to main memory
	*/    
	BCACHE_wb(output, MAX_RECEIVE_SIZE, 1);

	NODE_putMsg(env, NULL, &msg, 0);
	break;
      }
    }
  }

  return 0x8000;
}
