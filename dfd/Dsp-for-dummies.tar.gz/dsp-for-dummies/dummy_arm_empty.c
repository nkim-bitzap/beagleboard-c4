/*
 * Copyright (C) 2010-2011 University of Texas at Austin
 *
 * Author: Dan Zhang <dan.zhang@mail.utexas.edu>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * Copyright (C) 2009-2010 Felipe Contreras
 * Copyright (C) 2009-2010 Nokia Corporation
 * Copyright (C) 2009 Igalia S.L
 *
 * Author: Felipe Contreras <felipe.contreras@nokia.com>
 *
 * This file may be used under the terms of the GNU Lesser General Public
 * License version 2.1, a copy of which is found in LICENSE included in the
 * packaging of this file.
 */

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <signal.h>
#include <stdio.h>

#include "dmm_buffer.h"
#include "dsp_bridge.h"
#include "log.h"
#include "dummy_dsp.h"
#include "dummy_arm.h"

int main(int argc, const char *argv[])
{
  struct dsp_node *node;
  struct dsp_msg msg, replyMsg;

  printf("Setting up dsp\n");
  node = setup_dsp();
  setup_dmm_buffers(node, MAX_SEND_SIZE, MAX_RECEIVE_SIZE);

  // Do some work

 
  dsp_finish(node); // run at end of program
}
