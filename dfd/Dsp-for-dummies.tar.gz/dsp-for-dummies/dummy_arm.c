/*
 * Copyright (C) 2010-2011 University of Texas at Austin
 *
 * Author: Dan Zhang <dan.zhang@mail.utexas.edu>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * Copyright (C) 2009-2010 Felipe Contreras
 * Copyright (C) 2009-2010 Nokia Corporation
 * Copyright (C) 2009 Igalia S.L
 *
 * Author: Felipe Contreras <felipe.contreras@nokia.com>
 *
 * This file may be used under the terms of the GNU Lesser General Public
 * License version 2.1, a copy of which is found in LICENSE included in the
 * packaging of this file.
 */

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <signal.h>
#include <stdio.h>

#include "dmm_buffer.h"
#include "dsp_bridge.h"
#include "log.h"
#include "dummy_dsp.h"
#include "dummy_arm.h"


void cpu_mmul(void* in, void* out, uint32_t size) {
  uint32_t i, j, k;
  uint32_t sum;

  uint32_t* a;
  uint32_t* b;
  uint32_t* c;
  // Generate matrices A and B
  a = (uint32_t*)in;
  b = &(a[size*size]); // matrix has dimensions size*size
  c = (uint32_t*)out;
  
  for(i = 0; i < size; i=i+1) {
    for(j = 0; j < size; j=j+1) {
      sum = 0; 
      for(k = 0; k < size; k=k+1) {
	sum += a[j*size+k]*b[k*size+i];
      }
      c[j*size + i] = sum;
    }
  }
}


void cpu_vadd(int matrixDim) {

}



int main(int argc, const char *argv[])
{
  printf("WRAPPER v4\n");
  struct dsp_node *node;
  struct dsp_msg msg, replyMsg;
  int matrixDim;
  int mode;
  int program;

  matrixDim = atoi(argv[1]);
  mode = atoi(argv[2]);
  program = atoi(argv[3]);
  printf("Matrix dimension = %d\n", matrixDim);


  if(mode == 1) {
    printf("Mode == CPU\n");  }

  printf("Setting up dsp\n");
  node = setup_dsp();
  //setup_dmm_buffers(node, 2*matrixDim*matrixDim*4, matrixDim*matrixDim*4);
  setup_dmm_buffers(node, MAX_SEND_SIZE, MAX_RECEIVE_SIZE);

  // Fill DMA input buffer with data
  int counter = 0;
  int i, j;
  printf("Input buffer: ");

  // Size is in bytes
  printf("\nMatrix A:\n");
  for(i = 0; i < matrixDim; i++) {
    for(j = 0; j < matrixDim; j++) {
      printf("%d ", counter);
      ((int*) input_buffer->data)[counter] = counter;
      counter++;
    }
    printf("\n");
  }
  printf("\nMatrix B:\n");
  for(i = 0; i < matrixDim; i++) {
    for(j = 0; j < matrixDim; j++) {
      printf("%d ", counter);
      ((int*) input_buffer->data)[counter] = counter;
      counter++;
    }
    printf("\n");
  }

  if(mode == 1) {
    printf("Processing on CPU\n\n");
    cpu_mmul(input_buffer->data, output_buffer->data, matrixDim);
  }
  else {
    printf("Processing on DSP\n\n");
    msg.cmd = program; //MATRIX_MUL_FAST; // Run matrix_mul with this data
    msg.arg_1 = matrixDim; //We're sending 2 matrices worth of data
    msg.arg_2 = 0; // Unused
    
    dsp_send(node, msg);
    
    // Do stuff while waiting
    
    //replyMsg = dsp_recv(node); // blocking
    while(!dsp_irecv(node, &replyMsg));
  }

  // Print out output?
  printf("\n\nOutput buffer: ");
  printf("\n\nMatrix C:\n");
  counter = 0;
  for(i = 0; i < matrixDim; i++) {
    for(j = 0; j < matrixDim; j++) {
      printf("%d ", ((int*)output_buffer->data)[counter]);
      counter++;
    }
    printf("\n");
  }

  dsp_finish(node); // run at end of program
}
